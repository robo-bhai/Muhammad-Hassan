"""
Customer Authentication Views — Professional OTP System
=========================================================
✅ Same page OTP verify
✅ Auto order placement
✅ Trust system
✅ Pending OTPs backup
✅ Email OTP sending
✅ Login/Register → Shop Page Redirect (FIXED)
✅ Welcome messages with Shop greeting
"""
from django.shortcuts import render, redirect, get_object_or_404
from ..shop_flags import flag_required
from django.contrib import messages
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.utils.timezone import now
from django.db import transaction
from django.core.cache import cache
from django.urls import reverse
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
from datetime import timedelta
from decimal import Decimal
import re
import json
import uuid
import logging

from ..models import (
    Customer, CustomerProfile, CustomerOTP, CustomerAddress,
    OTPAuditLog, CompanyInfo, Notification,
    SaleOrder, SaleOrderItem, Sale, Warehouse,
    Product, Inventory
)

from ..decorators import customer_login_required
from ..security.security_utils import safe_error

logger = logging.getLogger(__name__)

# ---- Brute-force bachao (vendor/rider login jaisa hi tareeqa) ----
LOGIN_MAX_ATTEMPTS = 5            # ek phone + ek IP se ghalat koshishen
LOGIN_MAX_ATTEMPTS_PER_IP = 40    # ek IP se saare phones milakar (phone-spraying)
LOGIN_LOCK_SECONDS = 10 * 60
REGISTER_MAX_PER_HOUR = 20        # ek IP se register koshishen (CGNAT/shared IP ke liye kholi rakhi)
LOGIN_LOCKED_MSG = '🔒 Bohat zyada koshishen. 10 minute baad dobara try karein.'
LOGIN_FAILED_MSG = '❌ Phone ya password ghalat hai'


def _count_login_failure(key, ip_key):
    cache.set(key, cache.get(key, 0) + 1, LOGIN_LOCK_SECONDS)
    cache.set(ip_key, cache.get(ip_key, 0) + 1, LOGIN_LOCK_SECONDS)


# ============================================
# HELPER FUNCTIONS
# ============================================

def get_client_ip(request):
    """Get client IP safely"""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0].strip()
    else:
        ip = request.META.get('REMOTE_ADDR', '')
    return ip or None


def is_valid_phone(phone):
    """Validate Pakistani phone"""
    pattern = r'^(\+92|92|0)?3\d{9}$'
    return bool(re.match(pattern, phone.replace(' ', '').replace('-', '')))


def normalize_phone(phone):
    """Normalize to +923XXXXXXXXX"""
    phone = phone.replace(' ', '').replace('-', '').replace('+', '')
    if phone.startswith('92'):
        phone = phone[2:]
    elif phone.startswith('0'):
        phone = phone[1:]
    return f'+92{phone}'


def safe_login(request, user):
    """Safe login with backend"""
    login(request, user, backend='django.contrib.auth.backends.ModelBackend')


# ============================================
# AUTO PLACE ORDER
# ============================================

def auto_place_order(request, customer):
    """
    AUTO PLACE ORDER after the OTP is verified
    """
    try:
        with transaction.atomic():
            # Step 1: Cart check
            cart = request.session.get('cart', {})
            if not cart:
                logger.warning(f"Cart is empty for {customer.name}")
                return None, "Cart is empty"
            
            # Step 2: Warehouse
            warehouse = Warehouse.objects.first()
            if not warehouse:
                return None, "There is no warehouse"
            
            # Step 3: Payment method
            payment_method = request.session.get('selected_payment', 'cod')
            valid_methods = ['cod']  # sirf Cash on Delivery
            if payment_method not in valid_methods:
                payment_method = 'cod'
            
            # Step 4: Duplicate check (30 sec)
            recent_order = SaleOrder.objects.filter(
                customer=customer,
                created_at__gte=now() - timedelta(seconds=30),
                status='pending'
            ).first()
            
            if recent_order:
                logger.info(f"Duplicate detected: {recent_order.order_no}")
                return recent_order, None
            
            # Step 5: Stock check
            product_ids = [item['product_id'] for item in cart.values()]
            products = Product.objects.in_bulk(product_ids)
            
            from . import cart_options
            from ..models.trade.product_options import resolve_selection
            for key, item in cart.items():
                if not products.get(item['product_id']):
                    return None, f"Product not found"
                _c, _e, opt_error = resolve_selection(products[item['product_id']], item.get('option_ids') or [])
                if opt_error:
                    return None, f"{item.get('name')}: {opt_error}. Cart se hata kar dobara chunein."
            
            # 🔒 Stock lock: inventory rows lock + pending orders ginkar check (overselling se bachao)
            from . import store_orders
            stock_error = store_orders.check_and_lock_stock(cart, warehouse)
            if stock_error:
                return None, stock_error
            
            # Step 5b: Store ke qaide (band store, minimum order, mixed cart) + delivery fee
            from .views_customer_portal import calculate_cart_data
            delivery_type = request.session.get('delivery_type', 'standard')
            cart_data = calculate_cart_data(cart, customer=customer, delivery_type=delivery_type)
            scheduled_for = store_orders.session_schedule(request.session)
            store_error = store_orders.validate_cart_for_order(cart, cart_data['subtotal'], scheduled_for)
            if store_error:
                return None, store_error
            delivery_charges = cart_data['delivery_charges']

            # Step 5b: Offers (coupon + Pro delivery + wallet); customer / coupon row lock
            from . import offers
            from . import coupons as coupon_logic
            summary = offers.prepare(cart, cart_data, customer, request.session, lock=True)
            if summary['coupon_code'] and summary['coupon_error']:
                request.session.pop(coupon_logic.SESSION_KEY, None)
                request.session.modified = True
                return None, summary['coupon_error'] + ' Coupon hata diya gaya, total dobara dekhein.'
            delivery_charges = summary['delivery']

            # Step 6: Create order
            order = SaleOrder.objects.create(
                **{**store_orders.store_order_fields(cart, cart_data, payment_method),
                   'delivery_fee': delivery_charges},
                customer=customer,
                warehouse=warehouse,
                order_date=now(),
                status='pending',
                scheduled_for=scheduled_for,
                notes=(f"🌐 WEB ORDER (OTP Verified) | Payment: {payment_method} | "
                       f"Delivery: {delivery_type} Rs. {delivery_charges}"),
                **offers.order_fields(summary),
                advance_payment=Decimal('0.00'),
                created_by=customer.portal_profile.user,
            )
            
            # Step 7: Add items
            total_amount = Decimal('0.00')
            order_summary = []
            
            for key, item in cart.items():
                product = products.get(item['product_id'])
                quantity = item['quantity']
                price = Decimal(str(item['price']))
                
                chosen, new_extras, _err = resolve_selection(product, item.get('option_ids') or [])
                price = price - Decimal(str(item.get('options_extra', 0) or 0)) + new_extras
                
                SaleOrderItem.objects.create(
                    order=order,
                    product=product,
                    qty=quantity,
                    price=price,
                    options_text=cart_options.options_text(chosen),
                    options_key=cart_options.order_line_key([o.id for o in chosen], item.get('note')),
                    options_extra=new_extras,
                    note=cart_options.clean_note(item.get('note')),
                )
                
                item_total = price * quantity
                total_amount += item_total
                
                order_summary.append({
                    'name': product.name + (f' ({cart_options.options_text(chosen)})' if chosen else ''),
                    'qty': quantity,
                    'price': float(price),
                    'total': float(item_total),
                })
            
            # Step 7b: Coupon ka istemal likho, wallet se paisa kato
            offers.finalize(order, summary, customer, request.session)

            # Step 8: Trust update
            customer.portal_profile.record_successful_order()
            
            # Step 9: Clear cart + session
            request.session['cart'] = {}
            request.session.pop('scheduled_for', None)
            request.session.pop('order_verified', None)
            request.session.pop('order_verified_at', None)
            request.session.pop('order_otp_phone', None)
            request.session.pop('order_otp_id', None)
            request.session.pop('order_token', None)
            request.session.pop('selected_payment', None)
            request.session.pop('delivery_type', None)
            request.session.modified = True
            request.session.save()

            # Step 9b: Store (vendor) ko naye order ki khabar
            store_orders.notify_vendor_new_order(order)
            
            # Step 10: Notify admin
            try:
                admins = User.objects.filter(is_superuser=True)
                for admin in admins:
                    Notification.send(
                        user=admin,
                        title=f'🛒 New Order - {customer.name}',
                        message=(
                            f'Order #{order.order_no}\n'
                            f'Amount: Rs. {total_amount:,.2f}\n'
                            f'Phone: {customer.contact_number}\n'
                            f'Items: {len(order_summary)}'
                        ),
                        notification_type='sale',
                        category='sales',
                        link=f'/orders/sale/{order.id}/'
                    )
            except Exception as e:
                logger.error(f"Notification error: {e}")
            
            # Step 11: WhatsApp
            try:
                from ..whatsapp_utils import WhatsAppSender
                if customer.contact_number:
                    WhatsAppSender.send_order_confirmation(
                        customer.contact_number,
                        order.order_no,
                        float(total_amount),
                        order_summary
                    )
            except Exception as e:
                logger.error(f"WhatsApp error: {e}")
            
            logger.info(f"✅ Order placed: {order.order_no}")
            return order, None
            
    except Exception as e:
        logger.error(f"Auto place order error: {e}")
        import traceback
        traceback.print_exc()
        return None, safe_error(e)


# ============================================
# 1. CUSTOMER REGISTER
# ============================================

@flag_required('customer_register_enabled')
def customer_register(request):
    """Customer registration - Email mandatory - Redirect to Shop after register"""
    if request.user.is_authenticated and hasattr(request.user, 'customer_profile'):
        return redirect('shop_home')   # ✅ CHANGE: my_account → shop_home
    
    if request.method == 'POST':
        try:
            reg_key = f"customer_register:{get_client_ip(request) or ''}"
            if cache.get(reg_key, 0) >= REGISTER_MAX_PER_HOUR:
                messages.error(request, '🔒 Bohat zyada koshishen. Thori der baad dobara try karein.')
                return redirect('customer_register')
            cache.set(reg_key, cache.get(reg_key, 0) + 1, 3600)
            
            full_name = request.POST.get('full_name', '').strip()[:100]
            phone = request.POST.get('phone', '').strip()[:20]
            email = request.POST.get('email', '').strip()[:100]
            city = request.POST.get('city', '').strip()[:100]
            address = request.POST.get('address', '').strip()[:500]
            password = request.POST.get('password', '')
            confirm_password = request.POST.get('confirm_password', '')
            
            # Validation
            if not full_name or len(full_name) < 3:
                messages.error(request, '❌ Enter your full name')
                return redirect('customer_register')
            
            if not phone or not is_valid_phone(phone):
                messages.error(request, '❌ Enter a valid phone number')
                return redirect('customer_register')
            
            # ✅ EMAIL MANDATORY
            if not email:
                messages.error(request, '❌ Email is required (for OTP verification)')
                return redirect('customer_register')
            
            try:
                validate_email(email)
            except ValidationError:
                messages.error(request, '❌ Enter a valid email address')
                return redirect('customer_register')
            
            if not city:
                messages.error(request, '❌ Enter a valid city')
                return redirect('customer_register')
            
            if not address or len(address) < 10:
                messages.error(request, '❌ Enter the full address')
                return redirect('customer_register')
            
            if not password or len(password) < 6:
                messages.error(request, '❌ Password kam az kam 6 characters')
                return redirect('customer_register')
            
            if password != confirm_password:
                messages.error(request, '❌ Passwords do not match')
                return redirect('customer_register')
            
            phone = normalize_phone(phone)
            
            if Customer.objects.filter(contact_number=phone).exists():
                messages.error(request, '⚠️ This phone is already registered')
                return redirect('customer_login')
            
            if User.objects.filter(email=email).exists():
                messages.error(request, '⚠️ This email is already registered')
                return redirect('customer_register')
            
            with transaction.atomic():
                # Username from phone
                username = phone.replace('+', '').replace(' ', '')
                counter = 1
                base_username = username
                while User.objects.filter(username=username).exists():
                    username = f"{base_username}_{counter}"
                    counter += 1
                
                name_parts = full_name.split()
                
                user = User.objects.create_user(
                    username=username,
                    email=email,
                    password=password,
                    first_name=name_parts[0] if name_parts else '',
                    last_name=' '.join(name_parts[1:]) if len(name_parts) > 1 else ''
                )
                
                full_address = f"{address}, {city}"
                
                customer = Customer.objects.create(
                    name=full_name,
                    contact_number=phone,
                    email=email,
                    address=full_address,
                    customer_code=f'CUS-{user.id:05d}',
                )
                
                profile = CustomerProfile.objects.create(
                    customer=customer,
                    user=user,
                    phone_verified=False,
                    email_verified=True,
                    last_login_at=now()
                )
                
                CustomerAddress.objects.create(
                    customer=customer,
                    address_type='home',
                    full_name=full_name,
                    phone=phone,
                    address_line_1=address,
                    city=city,
                    is_default=True,
                )
                
                safe_login(request, user)
                request.session.save()
            
            # ✅ WELCOME MESSAGE WITH SHOP GREETING
            messages.success(
                request, 
                f'🎉 Welcome {customer.name}! Shop par khush aamdeed.'
            )
            return redirect('shop_home')   # ✅ CHANGE: my_account → shop_home
            
        except Exception as e:
            logger.error(f"Register error: {e}")
            messages.error(request, '❌ There was a problem with registration')
            return redirect('customer_register')
    
    company = CompanyInfo.objects.first()
    context = {
        'company_name': company.name if company else 'Shop',
        'page_title': 'Create Account',
    }
    return render(request, 'customer_portal/auth/register.html', context)


# ============================================
# 2. CUSTOMER LOGIN
# ============================================

@flag_required('customer_login_enabled')
def customer_login(request):
    """Customer login - Redirect to shop page after login"""
    if request.user.is_authenticated and hasattr(request.user, 'customer_profile'):
        next_url = request.GET.get('next')
        if next_url and next_url.startswith('/'):
            return redirect(next_url)
        return redirect('shop_home')   # ✅ CHANGE: my_account → shop_home
    
    if request.method == 'POST':
        try:
            phone = request.POST.get('phone', '').strip()[:20]
            password = request.POST.get('password', '')
            next_url = request.POST.get('next') or request.GET.get('next', '')
            
            if not phone or not password:
                messages.error(request, '❌ Enter both phone and password')
                return redirect('customer_login')
            
            phone = normalize_phone(phone)
            
            ip = get_client_ip(request) or ''
            key = f"customer_login_fail:{phone}:{ip}"
            ip_key = f"customer_login_fail_ip:{ip}"
            if (cache.get(key, 0) >= LOGIN_MAX_ATTEMPTS
                    or cache.get(ip_key, 0) >= LOGIN_MAX_ATTEMPTS_PER_IP):
                messages.error(request, LOGIN_LOCKED_MSG)
                return redirect('customer_login')
            
            customer = Customer.objects.filter(contact_number=phone).first()
            if not customer or not hasattr(customer, 'portal_profile'):
                _count_login_failure(key, ip_key)
                messages.error(request, LOGIN_FAILED_MSG)
                return redirect('customer_login')
            
            user = customer.portal_profile.user
            if not user:
                _count_login_failure(key, ip_key)
                messages.error(request, LOGIN_FAILED_MSG)
                return redirect('customer_login')
            
            if user.is_superuser or user.is_staff:
                messages.error(request, '❌ This is an admin account')
                return redirect('login')
            
            authenticated_user = authenticate(
                request, username=user.username, password=password
            )
            
            if authenticated_user:
                cache.delete(key)
                safe_login(request, authenticated_user)
                request.session.save()
                
                customer.portal_profile.last_login_at = now()
                customer.portal_profile.save()
                
                # ✅ WELCOME MESSAGE WITH SHOP GREETING
                messages.success(
                    request, 
                    f'🎉 Welcome back, {customer.name}! Shop par khush aamdeed.'
                )
                
                if next_url and next_url.startswith('/'):
                    return redirect(next_url)
                
                return redirect('shop_home')   # ✅ CHANGE: my_account → shop_home
            else:
                _count_login_failure(key, ip_key)
                messages.error(request, LOGIN_FAILED_MSG)
                return redirect('customer_login')
                
        except Exception as e:
            logger.error(f"Login error: {e}")
            messages.error(request, '❌ There was a problem with login')
            return redirect('customer_login')
    
    context = {
        'page_title': 'Login',
        'next': request.GET.get('next', ''),
    }
    return render(request, 'customer_portal/auth/login.html', context)


# ============================================
# 3. CUSTOMER LOGOUT
# ============================================

def customer_logout(request):
    """Logout with session flush + admin presence offline"""
    from ..models import AdminPresence
    
    # ✅ Mark admin offline (if staff)
    if request.user.is_authenticated and request.user.is_staff:
        try:
            AdminPresence.mark_offline(request.user)
        except Exception:
            pass
    
    request.session.flush()
    logout(request)
    messages.success(request, '👋 You have been logged out. See you again!')
    return redirect('shop_home')


# ============================================
# 4. MY ACCOUNT
# ============================================

@customer_login_required
def my_account(request):
    """Customer dashboard"""
    if not hasattr(request.user, 'customer_profile'):
        return redirect('shop_home')
    
    profile = request.user.customer_profile
    customer = profile.customer
    
    from django.db.models import Sum
    
    orders = SaleOrder.objects.filter(customer=customer).order_by('-order_date')
    
    stats = {
        'total_orders': orders.count(),
        'pending_orders': orders.filter(
            status__in=['pending', 'confirmed', 'processing', 'ready', 'partially_delivered']
        ).count(),
        'delivered_orders': orders.filter(status='delivered').count(),
        'cancelled_orders': orders.filter(status='cancelled').count(),
        'total_spent': SaleOrderItem.objects.filter(
            order__customer=customer,
            order__status='delivered'
        ).aggregate(total=Sum('total_amt'))['total'] or 0,
    }
    
    recent_orders = orders[:5]
    for order in recent_orders:
        order.calculated_total = sum(item.total_amt for item in order.items.all())
    
    default_address = customer.addresses.filter(is_default=True).first()
    company = CompanyInfo.objects.first()
    
    context = {
        'company_name': company.name if company else 'Shop',
        'profile': profile,
        'customer': customer,
        'stats': stats,
        'recent_orders': recent_orders,
        'default_address': default_address,
        'page_title': 'My Account',
    }
    return render(request, 'customer_portal/account/dashboard.html', context)


# ============================================
# 5. SEND OTP WITH DIRECT TOKEN LINK
# ============================================

@customer_login_required
def send_order_otp(request):
    """Send OTP — email + notification"""
    if not hasattr(request.user, 'customer_profile'):
        return JsonResponse({'success': False, 'message': 'Login required'})
    
    profile = request.user.customer_profile
    customer = profile.customer
    phone = customer.contact_number
    
    if not phone:
        return JsonResponse({'success': False, 'message': 'Phone number not found'})
    
    # ✅ EMAIL CHECK
    if not customer.email:
        return JsonResponse({
            'success': False,
            'message': 'Email required! Please add email to your account first.',
            'requires_email': True,
        })
    
    # Trusted customer skip
    if profile.should_skip_order_otp():
        return JsonResponse({
            'success': True,
            'skip_otp': True,
            'message': 'Trusted customer - OTP not required'
        })
    
    try:
        # Generate order token
        order_token = str(uuid.uuid4()).replace('-', '')[:8].upper()
        attempts = 0
        while CustomerOTP.objects.filter(
            order_token=order_token, is_used=False
        ).exists() and attempts < 5:
            order_token = str(uuid.uuid4()).replace('-', '')[:8].upper()
            attempts += 1

        # ✅ DIRECT VERIFICATION LINK
        verify_url = request.build_absolute_uri(
            reverse('verify_order_token', kwargs={'token': order_token})
        )
        
        # ✅ Generate OTP WITH EMAIL & VERIFICATION LINK
        otp = CustomerOTP.generate_otp(
            phone=phone,
            purpose='order',
            customer_name=customer.name,
            customer_email=customer.email,
            ip_address=get_client_ip(request),
            user_agent=request.META.get('HTTP_USER_AGENT', '')[:500],
            order_token=order_token,
            verify_url=verify_url,
        )
        
        # Save to session
        request.session['order_otp_phone'] = phone
        request.session['order_otp_id'] = otp.id
        request.session['order_token'] = order_token
        request.session.modified = True
        request.session.save()
        
        # Mask email for display
        email = customer.email
        if '@' in email:
            name, domain = email.split('@')
            masked_email = f"{name[:2]}***@{domain}"
        else:
            masked_email = email
        
        # Response
        if otp.is_sent_to_customer:
            return JsonResponse({
                'success': True,
                'skip_otp': False,
                'message': f'✅ OTP and verification link sent to {masked_email}',
                'otp_id': otp.id,
                'order_token': order_token,
                'email_sent': True,
            })
        else:
            return JsonResponse({
                'success': True,
                'skip_otp': False,
                'message': f'⚠️ OTP generated but email failed. Contact admin.',
                'otp_id': otp.id,
                'order_token': order_token,
                'email_sent': False,
            })
        
    except Exception as e:
        logger.error(f"Send OTP error: {e}")
        return JsonResponse({'success': False, 'message': safe_error(e)})


# ============================================
# 6. VERIFY VIA MAGIC EMAIL LINK (CLICK ACTION)
# ============================================

@customer_login_required
def verify_order_token(request, token):
    """Directly place order when user clicks email token link"""
    if not hasattr(request.user, 'customer_profile'):
        messages.error(request, 'Please log in to continue.')
        return redirect('login')
    
    try:
        # Check active & unused token
        otp_obj = CustomerOTP.objects.filter(
            order_token=token,
            is_used=False,
            purpose='order'
        ).first()

        if not otp_obj:
            messages.error(request, 'Invalid or expired verification link.')
            return redirect('/shop/cart/')

        # Check expiry (if method exists on your model)
        if hasattr(otp_obj, 'is_expired') and otp_obj.is_expired():
            messages.error(request, 'This verification link has expired.')
            return redirect('/shop/cart/')

        # Mark OTP as used
        otp_obj.is_used = True
        otp_obj.save(update_fields=['is_used'])

        profile = request.user.customer_profile
        phone = profile.customer.contact_number

        # Session Setup
        request.session['order_verified'] = True
        request.session['order_verified_at'] = now().isoformat()
        request.session['order_otp_phone'] = phone
        request.session['order_token'] = token
        request.session.modified = True
        request.session.save()

        # Update profile phone verification state
        profile.phone_verified = True
        profile.save(update_fields=['phone_verified'])

        # ✅ AUTO PLACE ORDER
        order, error = auto_place_order(request, profile.customer)

        if order:
            messages.success(request, '✅ Verification successful! Order placed.')
            return redirect(f'/shop/order-success/{order.id}/')
        else:
            messages.error(request, f'Verified, but failed to place order: {error}')
            return redirect('/shop/cart/')

    except Exception as e:
        logger.error(f"Token verification error: {e}")
        messages.error(request, 'An error occurred during verification.')
        return redirect('/shop/cart/')


# ============================================
# 7. VERIFY OTP — MANUAL CODE INPUT
# ============================================

@customer_login_required
def verify_order_otp(request):
    """Verify OTP code — Auto order place"""
    if not hasattr(request.user, 'customer_profile'):
        return JsonResponse({'success': False, 'message': 'Login required'})
    
    if request.method != 'POST':
        return JsonResponse({'success': False, 'message': 'POST required'})
    
    try:
        data = json.loads(request.body) if request.body else {}
        otp_code = data.get('otp_code', '').strip()
        
        if not otp_code or len(otp_code) != 6:
            return JsonResponse({'success': False, 'message': 'Please enter 6-digit OTP'})
        
        phone = request.session.get('order_otp_phone')
        if not phone:
            return JsonResponse({'success': False, 'message': 'Session expired'})
        
        success, otp_obj, message = CustomerOTP.find_and_verify(
            phone=phone,
            code=otp_code,
            purpose='order'
        )
        
        if not success:
            return JsonResponse({'success': False, 'message': message})
        
        request.session['order_verified'] = True
        request.session['order_verified_at'] = now().isoformat()
        request.session['order_otp_phone'] = phone
        request.session.modified = True
        request.session.save()
        
        profile = request.user.customer_profile
        profile.phone_verified = True
        profile.save(update_fields=['phone_verified'])
        
        # ✅ AUTO ORDER PLACE
        order, error = auto_place_order(request, profile.customer)
        
        if order:
            return JsonResponse({
                'success': True,
                'message': '✅ OTP verified! Order placed.',
                'redirect_url': f'/shop/order-success/{order.id}/',
            })
        else:
            return JsonResponse({
                'success': True,
                'message': f'✅ OTP verified! But the order was not placed: {error}',
                'redirect_url': '/shop/cart/',
            })
        
    except Exception as e:
        logger.error(f"Verify OTP error: {e}")
        return JsonResponse({'success': False, 'message': safe_error(e)})


# ============================================
# 8. SAVE PAYMENT METHOD
# ============================================

@customer_login_required
def save_payment_method(request):
    """Save payment method to session"""
    if request.method != 'POST':
        return JsonResponse({'success': False})
    
    try:
        data = json.loads(request.body)
        payment_method = data.get('payment_method', 'cod')
        
        valid_methods = ['cod']  # sirf Cash on Delivery
        if payment_method not in valid_methods:
            payment_method = 'cod'
        
        request.session['selected_payment'] = payment_method
        request.session.modified = True
        
        return JsonResponse({'success': True})
    except Exception as e:
        return JsonResponse({'success': False, 'message': safe_error(e)})


# ============================================
# 9. VERIFY OTP LATER
# ============================================

def verify_otp_later(request):
    """Verify OTP from Pending OTPs page"""
    prefill_phone = request.GET.get('phone', '').strip()[:20]
    prefill_token = request.GET.get('token', '').strip().upper()[:8]
    
    if request.method == 'POST':
        try:
            phone = request.POST.get('phone', '').strip()[:20]
            order_token = request.POST.get('order_token', '').strip().upper()[:8]
            otp_code = request.POST.get('otp_code', '').strip()
            
            if not all([phone, order_token, otp_code]):
                messages.error(request, '❌ Please fill all fields')
                return redirect(f"/shop/verify-otp-later/?phone={prefill_phone}&token={prefill_token}")
            
            if len(otp_code) != 6:
                messages.error(request, '❌ Please enter 6-digit OTP')
                return redirect(f"/shop/verify-otp-later/?phone={prefill_phone}&token={prefill_token}")
            
            phone = normalize_phone(phone)
            otp = CustomerOTP.find_by_token(order_token, phone)
            
            if not otp:
                messages.error(request, '❌ Invalid Order Token or Phone Number')
                return redirect(f"/shop/verify-otp-later/?phone={phone}&token={order_token}")
            
            if otp.is_locked():
                remaining = int((otp.locked_until - now()).total_seconds() / 60)
                messages.error(request, f'❌ Too many attempts. Try again in {remaining} minutes.')
                return redirect(f"/shop/verify-otp-later/?phone={phone}&token={order_token}")
            
            if otp.is_expired():
                messages.error(request, '❌ OTP expired. Please place a new order.')
                return redirect(f"/shop/verify-otp-later/?phone={phone}&token={order_token}")
            
            if not otp.verify(otp_code):
                otp.increment_attempts()
                attempts_left = otp.max_attempts - otp.attempts
                if attempts_left > 0:
                    messages.error(request, f'❌ Invalid OTP. {attempts_left} attempts remaining.')
                else:
                    messages.error(request, '❌ Too many failed attempts. Try again after 30 minutes.')
                return redirect(f"/shop/verify-otp-later/?phone={phone}&token={order_token}")
            
            otp.mark_used()
            
            customer = Customer.objects.filter(contact_number=phone).first()
            
            if not customer or not customer.portal_profile.user:
                messages.error(request, '❌ Customer account not found')
                return redirect(f"/shop/verify-otp-later/?phone={phone}&token={order_token}")
            
            # Session flags
            request.session['order_verified'] = True
            request.session['order_verified_at'] = now().isoformat()
            request.session['order_token'] = order_token
            request.session.modified = True
            
            # Login
            safe_login(request, customer.portal_profile.user)
            
            request.session['order_verified'] = True
            request.session['order_verified_at'] = now().isoformat()
            request.session['order_token'] = order_token
            request.session.modified = True
            request.session.save()
            
            customer.portal_profile.phone_verified = True
            customer.portal_profile.save(update_fields=['phone_verified'])
            
            try:
                OTPAuditLog.objects.create(
                    phone=phone,
                    action='verify_success',
                    success=True,
                    notes=f"Late OTP via token: {order_token}"
                )
            except Exception:
                pass
            
            # Auto order place
            order, error = auto_place_order(request, customer)
            
            if order:
                messages.success(request, f'🎉 Order #{order.order_no} placed!')
                return redirect('order_success_page', order_id=order.id)
            else:
                messages.warning(request, f'⚠️ OTP verified, but the order was not placed: {error}')
                return redirect('cart_view')
                
        except Exception as e:
            logger.error(f"Verify OTP later error: {e}")
            messages.error(request, f'❌ Error: {safe_error(e)}')
            return redirect('verify_otp_later')
    
    company = CompanyInfo.objects.first()
    context = {
        'company_name': company.name if company else 'Shop',
        'page_title': 'Verify OTP',
        'prefill_phone': prefill_phone,
        'prefill_token': prefill_token,
    }
    return render(request, 'customer_portal/auth/verify_otp_later.html', context)


# ============================================
# 10. PLACE ORDER DIRECT (Trusted / Verified)
# ============================================

@flag_required('shop_ordering_enabled')
@customer_login_required
def place_order_direct(request):
    """
    For a Trusted/Verified customer — Direct order placement
    """
    if not hasattr(request.user, 'customer_profile'):
        return JsonResponse({'success': False, 'message': 'Login required'})
    
    if request.method != 'POST':
        return JsonResponse({'success': False, 'message': 'POST required'})
    
    try:
        profile = request.user.customer_profile
        customer = profile.customer
        
        # Trusted ya Verified hona chahiye
        is_trusted = profile.should_skip_order_otp()
        is_verified = request.session.get('order_verified', False)
        
        if not (is_trusted or is_verified):
            return JsonResponse({
                'success': False,
                'message': 'OTP verification is required'
            })
        
        # Checkout page ka chuna hua payment/delivery (JSON body) session mein rakho
        try:
            body = json.loads(request.body) if request.body else {}
        except (ValueError, TypeError):
            body = {}
        if body.get('payment_method') in ('cod',):
            request.session['selected_payment'] = body['payment_method']
        if body.get('delivery_type') in ('standard', 'express', 'pickup'):
            request.session['delivery_type'] = body['delivery_type']

        # Auto order place
        order, error = auto_place_order(request, customer)
        
        if order:
            return JsonResponse({
                'success': True,
                'message': f'Order #{order.order_no} placed!',
                'redirect_url': f'/shop/order-success/{order.id}/',
            })
        else:
            return JsonResponse({
                'success': False,
                'message': error or 'Order was not placed'
            })
    
    except Exception as e:
        logger.error(f"Place order direct error: {e}")
        return JsonResponse({'success': False, 'message': safe_error(e)})