"""Group package: catalog, production."""
