"""Group package: hr, shareholders."""
